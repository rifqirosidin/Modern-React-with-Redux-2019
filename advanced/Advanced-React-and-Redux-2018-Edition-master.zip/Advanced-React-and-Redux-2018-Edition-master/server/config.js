module.exports = {
  secret: 'qwertyQWERTYYqwerty'
}