import React from 'react';

export default () => {
  return (
    <h3>
      Welcome! Sing up or sign in!
    </h3>
  )
};